import json
import os
import sys

import joblib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.append(HERE)
from preprocess import clean_text  # noqa: E402

MODEL_PATH = os.path.join(HERE, "saved_model", "model.joblib")
METRICS_PATH = os.path.join(HERE, "saved_model", "metrics.json")
_model = None


def _load():
    global _model
    if _model is None:
        try:
            _model = joblib.load(MODEL_PATH)
        except Exception:
            # Model file missing, or saved by a different scikit-learn version:
            # retrain automatically (takes about a minute).
            print("Model could not be loaded - training it now...")
            import train_model
            train_model.main()
            _model = joblib.load(MODEL_PATH)
    return _model


def predict_batch(texts):
    model = _load()
    texts = [t if isinstance(t, str) else "" for t in texts]
    probs = model.predict_proba([clean_text(t) for t in texts])
    out = []
    for t, p in zip(texts, probs):
        i = int(p.argmax())
        out.append({"text": t, "sentiment": str(model.classes_[i]),
                    "confidence": round(float(p[i]) * 100, 2),
                    "scores": {str(c): round(float(x) * 100, 2) for c, x in zip(model.classes_, p)}})
    return out


def predict_sentiment(text):
    return predict_batch([text])[0]


def get_metrics():
    if not os.path.exists(METRICS_PATH):
        return None
    with open(METRICS_PATH) as f:
        return json.load(f)


if __name__ == "__main__":
    for r in predict_batch(["I absolutely love this, amazing!", "Worst experience ever, so disappointed.",
                            "The package arrived on Tuesday."]):
        print(f"{r['sentiment']:9} {r['confidence']:6}%  {r['text']}")
