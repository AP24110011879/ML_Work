"""Train + evaluate the sentiment model. Run from project root:
       python ml/train_model.py
Uses dataset/twitter_training.csv (Kaggle, 3-class) if present, otherwise
dataset/social_sentiment.csv (built from NLTK tweets)."""
import json
import os
import sys

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocess import clean_text  # noqa: E402

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KAGGLE = os.path.join(BASE, "dataset", "twitter_training.csv")
BUILTIN = os.path.join(BASE, "dataset", "social_sentiment.csv")
OUT_DIR = os.path.join(BASE, "ml", "saved_model")
LABELS = ["Negative", "Neutral", "Positive"]


def load():
    if os.path.exists(KAGGLE):
        name = "Kaggle Twitter Entity Sentiment (twitter_training.csv)"
        df = pd.read_csv(KAGGLE, header=None, names=["id", "entity", "sentiment", "text"])
        df["sentiment"] = df["sentiment"].replace({"Irrelevant": "Neutral"})
    else:
        name = "NLTK twitter_samples (social_sentiment.csv)"
        df = pd.read_csv(BUILTIN)
    df = df.dropna(subset=["text", "sentiment"])
    df = df[df["sentiment"].isin(LABELS)].drop_duplicates("text")
    return name, df


def main():
    name, df = load()
    print("Dataset:", name)
    print(df["sentiment"].value_counts(), "\n")
    df["clean"] = df["text"].apply(clean_text)
    df = df[df["clean"].str.len() > 0]

    Xtr, Xte, ytr, yte = train_test_split(
        df["clean"], df["sentiment"], test_size=0.2, random_state=42,
        stratify=df["sentiment"])

    model = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True,
                                  max_features=60000)),
        ("clf", LogisticRegression(max_iter=1000, C=3.0, class_weight="balanced")),
    ])
    print("Training...")
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)

    rep = classification_report(yte, pred, labels=LABELS, output_dict=True, zero_division=0)
    metrics = {
        "dataset": name,
        "model": "TF-IDF (1-2 grams) + Logistic Regression",
        "train_size": int(len(Xtr)), "test_size": int(len(Xte)),
        "accuracy": round(accuracy_score(yte, pred), 4),
        "labels": LABELS,
        "per_class": {l: {"precision": round(rep[l]["precision"], 4),
                          "recall": round(rep[l]["recall"], 4),
                          "f1_score": round(rep[l]["f1-score"], 4),
                          "support": int(rep[l]["support"])} for l in LABELS},
        "macro_avg": {"precision": round(rep["macro avg"]["precision"], 4),
                      "recall": round(rep["macro avg"]["recall"], 4),
                      "f1_score": round(rep["macro avg"]["f1-score"], 4)},
        "confusion_matrix": confusion_matrix(yte, pred, labels=LABELS).tolist(),
    }
    os.makedirs(OUT_DIR, exist_ok=True)
    joblib.dump(model, os.path.join(OUT_DIR, "model.joblib"))
    with open(os.path.join(OUT_DIR, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    print(classification_report(yte, pred, zero_division=0))
    print("Accuracy:", metrics["accuracy"])
    print("Saved model + metrics to", OUT_DIR)


if __name__ == "__main__":
    main()
