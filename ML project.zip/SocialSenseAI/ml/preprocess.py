import re

# Negation / intensity words are kept: removing them would flip meanings.
KEEP = {"not", "no", "nor", "never", "very", "too", "against"}
STOP = {
    "a", "an", "the", "and", "or", "but", "if", "while", "of", "at", "by", "for",
    "with", "about", "to", "from", "in", "out", "on", "off", "over", "under",
    "again", "then", "once", "here", "there", "when", "where", "why", "how",
    "all", "any", "both", "each", "few", "more", "most", "other", "some", "such",
    "only", "own", "same", "so", "than", "can", "will", "just", "should", "now",
    "i", "me", "my", "we", "our", "you", "your", "he", "him", "his", "she", "her",
    "it", "its", "they", "them", "their", "what", "which", "who", "whom", "this",
    "that", "these", "those", "am", "is", "are", "was", "were", "be", "been",
    "being", "have", "has", "had", "having", "do", "does", "did", "doing",
    "as", "until", "because", "into", "through", "during", "before", "after",
    "above", "below", "up", "down", "s", "t", "rt", "amp",
}
STOPWORDS = STOP - KEEP


def clean_text(text):
    """Lowercase, strip URLs/mentions/symbols/emoji/numbers, drop stopwords."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"@\w+", " ", text)
    text = text.replace("#", " ")
    text = re.sub(r"n't\b", " not", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    words = [w for w in text.split() if w not in STOPWORDS]
    return " ".join(words)


if __name__ == "__main__":
    print(clean_text("I LOVE this!!! Check https://example.com @friend #awesome"))
