"""SocialSense AI - Flask application.  Run:  python backend/app.py"""
import csv
import io
import os
import sys
from functools import wraps

import pandas as pd
from flask import (Flask, Response, jsonify, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "ml"))

import config  # noqa: E402
import database as db  # noqa: E402
import social_connectors as sc  # noqa: E402
from predict import get_metrics, predict_batch  # noqa: E402

app = Flask(__name__, template_folder=os.path.join(ROOT, "templates"),
            static_folder=os.path.join(ROOT, "static"))
app.secret_key = config.SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB upload limit
db.init_db()


# ------------------------------------------------------------------ helpers
def login_required(view):
    @wraps(view)
    def wrapper(*a, **kw):
        if "user_id" not in session:
            if request.path.startswith("/api/"):
                return jsonify(error="Please log in first."), 401
            return redirect(url_for("login"))
        return view(*a, **kw)
    return wrapper


def percent(part, total):
    return round(part * 100 / total, 1) if total else 0.0


def overall_opinion(pos, neg, neu):
    total = pos + neg + neu
    if not total:
        return "No data"
    if pos >= neg and pos >= neu:
        top, label = pos, "Mostly Positive"
    elif neg >= pos and neg >= neu:
        top, label = neg, "Mostly Negative"
    else:
        top, label = neu, "Mostly Neutral"
    if abs(pos - neg) <= total * 0.05 and neu < max(pos, neg):
        return "Mixed / Divided"
    return label


def run_and_save(texts, title, source):
    texts = [str(t).strip() for t in texts if str(t).strip()][:config.MAX_COMMENTS]
    if not texts:
        return None, "No comments found to analyze."
    results = predict_batch(texts)
    aid = db.save_analysis(session["user_id"], title, source, results)
    return aid, None


def analysis_payload(aid):
    a, comments = db.get_analysis(session["user_id"], aid)
    if not a:
        return None
    a["positive_pct"] = percent(a["positive"], a["total"])
    a["negative_pct"] = percent(a["negative"], a["total"])
    a["neutral_pct"] = percent(a["neutral"], a["total"])
    a["opinion"] = overall_opinion(a["positive"], a["negative"], a["neutral"])
    a["comments"] = comments
    return a


# ------------------------------------------------------------------ pages
@app.route("/")
def landing():
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        if not name or "@" not in email or len(pw) < 6:
            return render_template("register.html", error="Enter a name, a valid email and a password of 6+ characters.")
        uid = db.create_user(name, email, generate_password_hash(pw))
        if not uid:
            return render_template("register.html", error="That email is already registered.")
        session["user_id"], session["name"] = uid, name
        return redirect(url_for("dashboard"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = db.get_user_by_email(email)
        if user and check_password_hash(user["password_hash"], request.form.get("password", "")):
            session["user_id"], session["name"] = user["id"], user["name"]
            return redirect(url_for("dashboard"))
        return render_template("login.html", error="Incorrect email or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("landing"))


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", active="dashboard")


@app.route("/analyze")
@login_required
def analyze_page():
    return render_template("analyze.html", active="analyze")


@app.route("/social")
@login_required
def social_page():
    return render_template("social.html", active="social",
                           youtube_ready=bool(config.GOOGLE_CLIENT_ID and config.GOOGLE_CLIENT_SECRET),
                           youtube_connected="yt_creds" in session,
                           x_ready=bool(config.X_BEARER_TOKEN))


@app.route("/history")
@login_required
def history_page():
    return render_template("history.html", active="history")


@app.route("/report/<int:aid>")
@login_required
def report_page(aid):
    a = analysis_payload(aid)
    if not a:
        return redirect(url_for("history_page"))
    return render_template("report.html", a=a, active="history")


@app.route("/model")
@login_required
def model_page():
    return render_template("model.html", active="model", m=get_metrics())


# ------------------------------------------------------------------ REST API
@app.route("/api/analyze-text", methods=["POST"])
@login_required
def api_analyze_text():
    text = (request.get_json(silent=True) or {}).get("text", "").strip()
    if not text:
        return jsonify(error="Please enter some text."), 400
    if len(text) > 5000:
        return jsonify(error="Text is too long (max 5000 characters)."), 400
    result = predict_batch([text])[0]
    aid = db.save_analysis(session["user_id"], text[:60] + ("..." if len(text) > 60 else ""), "Text", [result])
    result["analysis_id"] = aid
    return jsonify(result)


def _read_csv_texts(file_storage):
    """Read comments from a CSV. Handles quoted CSVs, and also single-column files
    where comments contain commas without quotes (very common in exports)."""
    raw = file_storage.read()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    rows = [r for r in csv.reader(io.StringIO(text)) if r and any(c.strip() for c in r)]
    if len(rows) < 2:
        return []
    header, body = [h.strip().lower() for h in rows[0]], rows[1:]
    preferred = ["comment", "comments", "text", "message", "review", "content", "tweet", "body"]
    if len(header) == 1:
        return [",".join(r).strip() for r in body]
    idx = next((header.index(p) for p in preferred if p in header), None)
    if idx is None:  # fall back to the column with the longest average text
        idx = max(range(len(header)), key=lambda i: sum(len(r[i]) for r in body if len(r) > i))
    return [r[idx].strip() for r in body if len(r) > idx and r[idx].strip()]


@app.route("/api/analyze-csv", methods=["POST"])
@login_required
def api_analyze_csv():
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".csv"):
        return jsonify(error="Please upload a .csv file."), 400
    try:
        texts = _read_csv_texts(f)
    except Exception as e:
        return jsonify(error=f"Could not read the CSV: {e}"), 400
    aid, err = run_and_save(texts, f"CSV: {f.filename}", "CSV Upload")
    if err:
        return jsonify(error=err), 400
    return jsonify(analysis_id=aid)


@app.route("/api/analyses")
@login_required
def api_analyses():
    rows = db.list_analyses(session["user_id"])
    for r in rows:
        r["opinion"] = overall_opinion(r["positive"], r["negative"], r["neutral"])
    return jsonify(rows)


@app.route("/api/analyses/<int:aid>", methods=["GET", "DELETE"])
@login_required
def api_analysis(aid):
    if request.method == "DELETE":
        ok = db.delete_analysis(session["user_id"], aid)
        return jsonify(deleted=ok), (200 if ok else 404)
    a = analysis_payload(aid)
    return (jsonify(a), 200) if a else (jsonify(error="Not found"), 404)


@app.route("/api/analyses/<int:aid>/csv")
@login_required
def api_analysis_csv(aid):
    a, comments = db.get_analysis(session["user_id"], aid)
    if not a:
        return jsonify(error="Not found"), 404
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["comment", "sentiment", "confidence_percent"])
    for c in comments:
        w.writerow([c["text"], c["sentiment"], c["confidence"]])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=socialsense_analysis_{aid}.csv"})


@app.route("/api/stats")
@login_required
def api_stats():
    t = db.user_totals(session["user_id"])
    t["positive_pct"] = percent(t["positive"], t["total"])
    t["negative_pct"] = percent(t["negative"], t["total"])
    t["neutral_pct"] = percent(t["neutral"], t["total"])
    t["opinion"] = overall_opinion(t["positive"], t["negative"], t["neutral"])
    t["recent"] = db.list_analyses(session["user_id"], limit=6)
    return jsonify(t)


@app.route("/api/model-metrics")
@login_required
def api_model_metrics():
    m = get_metrics()
    return (jsonify(m), 200) if m else (jsonify(error="Model not trained"), 404)


# ------------------------------------------------------------------ social media
@app.route("/api/social/demo", methods=["POST"])
@login_required
def api_social_demo():
    df = pd.read_csv(config.SAMPLE_CSV)
    aid, err = run_and_save(df["comment"].tolist(), "Sample dataset demo", "Demo Dataset")
    return jsonify(analysis_id=aid) if not err else (jsonify(error=err), 400)


def _creds_from_session():
    d = session.get("yt_creds")
    if not d:
        return None
    from google.oauth2.credentials import Credentials
    return Credentials(**d)


def _youtube_flow():
    from google_auth_oauthlib.flow import Flow
    os.environ.setdefault("OAUTHLIB_INSECURE_TRANSPORT", "1")   # allow http://localhost during development
    os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")
    cfg = {"web": {"client_id": config.GOOGLE_CLIENT_ID, "client_secret": config.GOOGLE_CLIENT_SECRET,
                   "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                   "token_uri": "https://oauth2.googleapis.com/token",
                   "redirect_uris": [config.GOOGLE_REDIRECT_URI]}}
    return Flow.from_client_config(cfg, scopes=["https://www.googleapis.com/auth/youtube.readonly"],
                                   redirect_uri=config.GOOGLE_REDIRECT_URI)


@app.route("/social/youtube/connect")
@login_required
def youtube_connect():
    if not (config.GOOGLE_CLIENT_ID and config.GOOGLE_CLIENT_SECRET):
        return redirect(url_for("social_page"))
    flow = _youtube_flow()
    url, state = flow.authorization_url(access_type="offline", prompt="consent")
    session["yt_state"], session["yt_verifier"] = state, flow.code_verifier
    return redirect(url)


@app.route("/social/youtube/callback")
@login_required
def youtube_callback():
    flow = _youtube_flow()
    flow.code_verifier = session.get("yt_verifier")
    try:
        flow.fetch_token(authorization_response=request.url)
    except Exception:
        return redirect(url_for("social_page"))
    c = flow.credentials
    session["yt_creds"] = {"token": c.token, "refresh_token": c.refresh_token, "token_uri": c.token_uri,
                           "client_id": c.client_id, "client_secret": c.client_secret, "scopes": list(c.scopes or [])}
    return redirect(url_for("social_page"))


@app.route("/social/youtube/disconnect")
@login_required
def youtube_disconnect():
    session.pop("yt_creds", None)
    return redirect(url_for("social_page"))


@app.route("/api/social/youtube/videos")
@login_required
def api_youtube_videos():
    creds = _creds_from_session()
    if not creds:
        return jsonify(error="Connect your YouTube account first."), 400
    try:
        return jsonify(sc.youtube_list_videos(creds))
    except sc.ConnectorError as e:
        return jsonify(error=str(e)), 400


@app.route("/api/social/posts", methods=["POST"])
@login_required
def api_social_posts():
    """Instagram / Facebook: list posts using a user-provided token (used once, never stored)."""
    d = request.get_json(silent=True) or {}
    token, acc = d.get("token", "").strip(), d.get("account_id", "").strip()
    if not token or not acc:
        return jsonify(error="Access token and account/page ID are required."), 400
    try:
        fn = {"instagram": sc.instagram_posts, "facebook": sc.facebook_posts}[d.get("platform")]
        return jsonify(fn(token, acc))
    except KeyError:
        return jsonify(error="Unsupported platform."), 400
    except sc.ConnectorError as e:
        return jsonify(error=str(e)), 400


@app.route("/api/social/analyze", methods=["POST"])
@login_required
def api_social_analyze():
    d = request.get_json(silent=True) or {}
    platform, post_id, title = d.get("platform"), d.get("post_id", "").strip(), d.get("title", "")
    try:
        if platform == "youtube":
            creds = _creds_from_session()
            if not creds:
                return jsonify(error="Connect your YouTube account first."), 400
            texts = sc.youtube_comments(creds, post_id)
        elif platform == "twitter":
            texts = sc.x_replies(post_id)
        elif platform == "instagram":
            texts = sc.instagram_comments(d.get("token", "").strip(), post_id)
        elif platform == "facebook":
            texts = sc.facebook_comments(d.get("token", "").strip(), post_id)
        else:
            return jsonify(error="Unsupported platform."), 400
    except sc.ConnectorError as e:
        return jsonify(error=str(e)), 400
    label = {"youtube": "YouTube", "twitter": "Twitter/X", "instagram": "Instagram", "facebook": "Facebook"}[platform]
    aid, err = run_and_save(texts, f"{label}: {title or post_id}"[:80], label)
    return jsonify(analysis_id=aid) if not err else (jsonify(error=err), 400)


@app.errorhandler(413)
def too_big(_):
    return jsonify(error="File too large (max 5 MB)."), 413


if __name__ == "__main__":
    app.run(debug=True, port=5000)
