import os
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE_DIR, ".env"))

SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key-before-deploying")
DB_PATH = os.path.join(BASE_DIR, "database", "socialsense.db")
SAMPLE_CSV = os.path.join(BASE_DIR, "dataset", "sample_comments.csv")

# --- YouTube (Google OAuth) ---
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:5000/social/youtube/callback")

# --- X (Twitter) API v2 app bearer token (reading replies needs a paid API tier) ---
X_BEARER_TOKEN = os.getenv("X_BEARER_TOKEN", "")

MAX_COMMENTS = 500   # safety limit per analysis
