"""
Connectors that use OFFICIAL platform APIs only (no scraping).

YouTube   : full Google OAuth 2.0 flow (see app.py) + YouTube Data API v3.
X/Twitter : API v2 recent search with an app Bearer Token (needs a plan that allows search).
Instagram : Instagram Graph API with a user-provided access token (Business/Creator account).
Facebook  : Graph API with a Page access token (Pages you manage).
Each function raises ConnectorError with a readable message on failure.
"""
import requests

from config import MAX_COMMENTS, X_BEARER_TOKEN

GRAPH = "https://graph.facebook.com/v19.0"


class ConnectorError(Exception):
    pass


def _get(url, **kw):
    try:
        r = requests.get(url, timeout=20, **kw)
    except requests.RequestException as e:
        raise ConnectorError(f"Network error: {e}")
    if r.status_code >= 400:
        try:
            msg = r.json()
        except Exception:
            msg = r.text[:200]
        raise ConnectorError(f"API error {r.status_code}: {msg}")
    return r.json()


# ---------------- YouTube ----------------
def youtube_service(credentials):
    from googleapiclient.discovery import build
    return build("youtube", "v3", credentials=credentials, cache_discovery=False)


def youtube_list_videos(credentials, max_results=25):
    yt = youtube_service(credentials)
    try:
        ch = yt.channels().list(part="contentDetails", mine=True).execute()
        items = ch.get("items", [])
        if not items:
            raise ConnectorError("No YouTube channel found for this Google account.")
        uploads = items[0]["contentDetails"]["relatedPlaylists"]["uploads"]
        pl = yt.playlistItems().list(part="snippet", playlistId=uploads, maxResults=max_results).execute()
    except ConnectorError:
        raise
    except Exception as e:
        raise ConnectorError(f"YouTube API error: {e}")
    return [{"id": i["snippet"]["resourceId"]["videoId"], "title": i["snippet"]["title"]}
            for i in pl.get("items", [])]


def youtube_comments(credentials, video_id):
    yt = youtube_service(credentials)
    comments, token = [], None
    try:
        while len(comments) < MAX_COMMENTS:
            resp = yt.commentThreads().list(part="snippet", videoId=video_id, maxResults=100,
                                            pageToken=token, textFormat="plainText").execute()
            for it in resp.get("items", []):
                comments.append(it["snippet"]["topLevelComment"]["snippet"]["textDisplay"])
            token = resp.get("nextPageToken")
            if not token:
                break
    except Exception as e:
        raise ConnectorError(f"YouTube API error (comments may be disabled): {e}")
    return comments[:MAX_COMMENTS]


# ---------------- X / Twitter ----------------
def x_replies(tweet_id):
    if not X_BEARER_TOKEN:
        raise ConnectorError("X_BEARER_TOKEN is not set in .env. The X API also requires a plan that allows search.")
    data = _get("https://api.x.com/2/tweets/search/recent",
                headers={"Authorization": f"Bearer {X_BEARER_TOKEN}"},
                params={"query": f"conversation_id:{tweet_id}", "max_results": 100, "tweet.fields": "text"})
    return [t["text"] for t in data.get("data", [])][:MAX_COMMENTS]


# ---------------- Instagram ----------------
def instagram_posts(token, ig_user_id):
    data = _get(f"{GRAPH}/{ig_user_id}/media",
                params={"fields": "id,caption,permalink", "limit": 25, "access_token": token})
    return [{"id": m["id"], "title": (m.get("caption") or "Post " + m["id"])[:70]} for m in data.get("data", [])]


def instagram_comments(token, media_id):
    data = _get(f"{GRAPH}/{media_id}/comments", params={"fields": "text", "limit": 100, "access_token": token})
    return [c["text"] for c in data.get("data", []) if c.get("text")][:MAX_COMMENTS]


# ---------------- Facebook ----------------
def facebook_posts(token, page_id):
    data = _get(f"{GRAPH}/{page_id}/posts", params={"fields": "id,message", "limit": 25, "access_token": token})
    return [{"id": p["id"], "title": (p.get("message") or "Post " + p["id"])[:70]} for p in data.get("data", [])]


def facebook_comments(token, post_id):
    data = _get(f"{GRAPH}/{post_id}/comments", params={"fields": "message", "limit": 100, "access_token": token})
    return [c["message"] for c in data.get("data", []) if c.get("message")][:MAX_COMMENTS]
