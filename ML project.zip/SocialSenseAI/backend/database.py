import sqlite3
from datetime import datetime

from config import DB_PATH


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        source TEXT NOT NULL,
        total INTEGER NOT NULL,
        positive INTEGER NOT NULL,
        negative INTEGER NOT NULL,
        neutral INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        analysis_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        sentiment TEXT NOT NULL,
        confidence REAL NOT NULL,
        FOREIGN KEY (analysis_id) REFERENCES analyses(id) ON DELETE CASCADE
    );
    """)
    conn.commit()
    conn.close()


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def create_user(name, email, password_hash):
    conn = get_db()
    try:
        cur = conn.execute("INSERT INTO users (name,email,password_hash,created_at) VALUES (?,?,?,?)",
                           (name, email, password_hash, now()))
        conn.commit()
        return cur.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def get_user_by_email(email):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    conn.close()
    return row


def get_user(user_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return row


def save_analysis(user_id, title, source, results):
    """results: list of dicts with text, sentiment, confidence."""
    pos = sum(1 for r in results if r["sentiment"] == "Positive")
    neg = sum(1 for r in results if r["sentiment"] == "Negative")
    neu = sum(1 for r in results if r["sentiment"] == "Neutral")
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO analyses (user_id,title,source,total,positive,negative,neutral,created_at) VALUES (?,?,?,?,?,?,?,?)",
        (user_id, title, source, len(results), pos, neg, neu, now()))
    aid = cur.lastrowid
    conn.executemany("INSERT INTO comments (analysis_id,text,sentiment,confidence) VALUES (?,?,?,?)",
                     [(aid, r["text"], r["sentiment"], r["confidence"]) for r in results])
    conn.commit()
    conn.close()
    return aid


def list_analyses(user_id, limit=None):
    conn = get_db()
    q = "SELECT * FROM analyses WHERE user_id=? ORDER BY id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = [dict(r) for r in conn.execute(q, (user_id,)).fetchall()]
    conn.close()
    return rows


def get_analysis(user_id, analysis_id):
    conn = get_db()
    a = conn.execute("SELECT * FROM analyses WHERE id=? AND user_id=?", (analysis_id, user_id)).fetchone()
    if not a:
        conn.close()
        return None, []
    c = [dict(r) for r in conn.execute(
        "SELECT text,sentiment,confidence FROM comments WHERE analysis_id=? ORDER BY id", (analysis_id,)).fetchall()]
    conn.close()
    return dict(a), c


def delete_analysis(user_id, analysis_id):
    conn = get_db()
    cur = conn.execute("DELETE FROM analyses WHERE id=? AND user_id=?", (analysis_id, user_id))
    conn.commit()
    conn.close()
    return cur.rowcount > 0


def user_totals(user_id):
    conn = get_db()
    r = conn.execute(
        "SELECT COALESCE(SUM(total),0) t, COALESCE(SUM(positive),0) p, COALESCE(SUM(negative),0) n, "
        "COALESCE(SUM(neutral),0) u, COUNT(*) c FROM analyses WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return {"total": r["t"], "positive": r["p"], "negative": r["n"], "neutral": r["u"], "analyses": r["c"]}
