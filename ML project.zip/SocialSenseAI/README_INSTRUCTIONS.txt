==========================================================================
  SocialSense AI - Social Media Sentiment Analysis using Machine Learning
  Setup & Run Instructions (for beginners)
==========================================================================

WHAT YOU GET
  A Flask website with a real scikit-learn model (TF-IDF + Logistic Regression)
  that classifies text as Positive / Negative / Neutral, with user accounts,
  dashboard, charts, CSV upload, history, reports and social media import.


--------------------------------------------------------------------------
1. INSTALL PYTHON (one time)
--------------------------------------------------------------------------
  - Install Python 3.10 or newer from https://www.python.org/downloads/
  - Windows: tick "Add Python to PATH" in the installer.
  - Check in a terminal:      python --version
    (On Mac/Linux you may need to type python3 instead of python.)


--------------------------------------------------------------------------
2. EXTRACT THE ZIP AND OPEN A TERMINAL IN THE PROJECT FOLDER
--------------------------------------------------------------------------
  - Right-click the zip -> Extract All. You get a folder named SocialSenseAI.
  - Open a terminal INSIDE that folder:
      Windows : open the folder, click the address bar, type  cmd  and press Enter
      Mac     : right-click the folder -> "New Terminal at Folder"
      VS Code : File -> Open Folder -> Terminal -> New Terminal


--------------------------------------------------------------------------
3. CREATE A VIRTUAL ENVIRONMENT AND INSTALL LIBRARIES
--------------------------------------------------------------------------
  Windows:
      python -m venv venv
      venv\Scripts\activate
      pip install -r requirements.txt

  Mac / Linux:
      python3 -m venv venv
      source venv/bin/activate
      pip install -r requirements.txt

  (You should see "(venv)" at the start of the terminal line.)
  PowerShell error "running scripts is disabled"? Run once:
      Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
  and activate again.


--------------------------------------------------------------------------
4. (OPTIONAL BUT RECOMMENDED) TRAIN THE MODEL YOURSELF
--------------------------------------------------------------------------
  A trained model is already included, so you can skip this. To train it
  yourself (good for your viva/demo, takes about 1 minute):

      python ml/train_model.py

  It prints accuracy, precision, recall, F1-score and the confusion matrix,
  and saves  ml/saved_model/model.joblib  and  ml/saved_model/metrics.json.
  These real numbers are what the "Model Performance" page shows.

  If the model file cannot be loaded (for example a different scikit-learn
  version), the app trains it automatically on first use.


--------------------------------------------------------------------------
5. RUN THE WEBSITE
--------------------------------------------------------------------------
      python backend/app.py

  Open your browser at:     http://127.0.0.1:5000
  Stop the server with:     Ctrl + C

  Note: the pages load Bootstrap, icons, fonts and Chart.js from the internet
  (CDN), so you need an internet connection when viewing the site.


--------------------------------------------------------------------------
6. HOW TO TEST EVERY FEATURE
--------------------------------------------------------------------------
  1. Landing page      -> http://127.0.0.1:5000 ; click "Get Started".
  2. Register          -> name, email, password (6+ characters). You are
                          logged in and taken to the dashboard.
  3. Logout / Login    -> sidebar "Logout", then log in again.
  4. Text analysis     -> "Analyze Text / CSV": click a sample chip, press
                          Analyze. You get Positive/Negative/Neutral, a
                          confidence score and probability bars. It is saved.
  5. CSV upload        -> same page, "CSV upload" tab, choose
                          dataset/sample_comments.csv. You are taken to a
                          report with charts and every comment's sentiment.
  6. Dashboard         -> totals, percentages, pie chart, bar chart, recent
                          analyses, overall audience sentiment.
  7. Reports           -> on a report page: "Download CSV", "Print / Save as
                          PDF", the summary paragraph, and the filter box.
  8. History           -> open or delete old analyses (trash icon).
  9. Model Performance -> real accuracy, precision, recall, F1, confusion
                          matrix from the test set.
 10. Social Media      -> "Run sample dataset demo" works without any keys.
                          Platform connections need credentials (section 7).

  CSV format: a column named  comment  (or text / message / review). Example:
        comment
        I love this video
        "Not good, very disappointed"
  Up to 500 comments are analyzed per upload (limit set in backend/config.py).


--------------------------------------------------------------------------
7. SOCIAL MEDIA INTEGRATIONS (official APIs only, no scraping)
--------------------------------------------------------------------------
  The website works fully WITHOUT these. Connections need credentials that
  only you can create. I could not test them against live accounts, so test
  with your own account before your demo.

  Create a file named  .env  (copy .env.example) in the project root.

  --- YouTube (recommended; works with a free Google account) ---
   1. https://console.cloud.google.com -> create a project.
   2. "APIs & Services" -> Library -> enable "YouTube Data API v3".
   3. "OAuth consent screen" -> External -> fill app name/email; under "Test
      users" add your own Google email.
   4. "Credentials" -> Create Credentials -> OAuth client ID -> Web application.
      Authorized redirect URI:  http://localhost:5000/social/youtube/callback
   5. Put the client ID and secret in .env (GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET).
   6. IMPORTANT: open the site as  http://localhost:5000  (not 127.0.0.1) so it
      matches the redirect URI.
   7. Social Media page -> YouTube -> Connect -> "Load my videos" -> Analyze.
   Permission requested: read-only access to your YouTube account.

  --- Instagram (Meta Graph API) ---
   Needs an Instagram Business/Creator account linked to a Facebook Page and a
   Meta developer app (developers.facebook.com). In Graph API Explorer generate
   an access token with instagram_basic + instagram_manage_comments, find your
   Instagram Business account ID, and paste both on the Instagram tab.
   Works for accounts you own while the app is in development mode.

  --- Facebook (Meta Graph API) ---
   Needs a Page you manage. Generate a Page access token with
   pages_read_engagement / pages_read_user_content and paste it with the
   Page ID on the Facebook tab. Other users' pages would need Meta App Review.

  --- Twitter / X ---
   Put your app Bearer Token in .env as X_BEARER_TOKEN, then enter a tweet ID.
   X now restricts reading replies to paid API plans. Without one, use
   CSV upload or the demo.

  Tokens pasted for Instagram/Facebook are used for that single request and
  are not saved to the database.

  Cannot get API access? Export comments to CSV (many tools and platform
  exports allow this) and use the CSV upload. Be honest about this in your
  demo; the CSV route is a legitimate, fully working path.


--------------------------------------------------------------------------
8. ABOUT THE DATASET AND MODEL ACCURACY (read before your viva)
--------------------------------------------------------------------------
  - By default the model is trained on  dataset/social_sentiment.csv, which
    prepare_dataset.py builds from the free NLTK 'twitter_samples' corpus:
        Positive / Negative : real tweets labelled by emoticon (corpus labels)
        Neutral             : tweets and chat messages with a VADER score of
                              exactly 0 (labelled by a lexicon, not by humans)
    These are WEAK labels, so accuracy is moderate (roughly 73% on the held-out
    test set when this zip was built) and the Neutral class is the weakest.
    The numbers on the Model Performance page are measured, not invented.

  - For a better model, use a human-labelled 3-class dataset:
      1. Create a free Kaggle account and download
         "Twitter Entity Sentiment Analysis" (twitter_training.csv).
      2. Put twitter_training.csv inside the  dataset/  folder.
      3. Run:  python ml/train_model.py
      The script detects it automatically (Irrelevant is merged into Neutral).
      Then restart the website; the new metrics appear on the Model page.

  - Rebuild the default dataset anytime:  python dataset/prepare_dataset.py
    (downloads NLTK data; needs internet).


--------------------------------------------------------------------------
9. PROJECT STRUCTURE
--------------------------------------------------------------------------
  SocialSenseAI/
  |-- README_INSTRUCTIONS.txt   this file
  |-- requirements.txt          Python libraries
  |-- .env.example              template for API keys (copy to .env)
  |-- backend/
  |   |-- app.py                Flask app: pages + REST API routes
  |   |-- database.py           SQLite tables and queries
  |   |-- social_connectors.py  YouTube / X / Instagram / Facebook API code
  |   |-- config.py             settings loaded from .env
  |-- ml/
  |   |-- preprocess.py         text cleaning (URLs, symbols, stopwords)
  |   |-- train_model.py        trains + evaluates the model
  |   |-- predict.py            loads the model for Flask (predict_batch)
  |   |-- saved_model/          model.joblib and metrics.json
  |-- dataset/
  |   |-- prepare_dataset.py    builds social_sentiment.csv from NLTK corpora
  |   |-- social_sentiment.csv  training data
  |   |-- sample_comments.csv   demo file for CSV upload
  |-- database/                 socialsense.db is created here automatically
  |-- templates/                HTML pages (Jinja2)
  |-- static/                   css/style.css, js/main.js

  HOW THE ML MODEL CONNECTS TO FLASK
  app.py imports predict_batch() from ml/predict.py. predict.py loads
  model.joblib once, cleans the text with preprocess.clean_text(), and returns
  the label plus probabilities. Routes in app.py (/api/analyze-text,
  /api/analyze-csv, /api/social/analyze) call it and save results in SQLite.

  REST API (login required): POST /api/analyze-text, POST /api/analyze-csv,
  GET /api/analyses, GET|DELETE /api/analyses/<id>, GET /api/analyses/<id>/csv,
  GET /api/stats, GET /api/model-metrics, POST /api/social/analyze.


--------------------------------------------------------------------------
10. COMMON ERRORS
--------------------------------------------------------------------------
  "python is not recognized"      -> reinstall Python with "Add to PATH" ticked,
                                     or use  py  instead of  python  on Windows.
  "No module named flask"         -> the virtual environment is not active, or
                                     pip install was skipped. Activate venv, then
                                     pip install -r requirements.txt
  "Address already in use"        -> port 5000 is busy (on Mac, AirPlay uses it).
                                     Change port=5000 at the bottom of
                                     backend/app.py to 5001 and open that port.
  Charts/icons missing            -> no internet (CDN files could not load).
  YouTube "redirect_uri_mismatch" -> the redirect URI in Google Cloud must be
                                     exactly http://localhost:5000/social/youtube/callback
                                     and you must browse via localhost:5000.
  Want to reset all data          -> stop the server, delete database/socialsense.db.

  For deployment, set a strong SECRET_KEY in .env and turn off debug mode
  (debug=False at the bottom of backend/app.py).
