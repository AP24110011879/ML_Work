const COLORS = {Positive: '#10b981', Negative: '#ef4444', Neutral: '#f59e0b'};
const EMOJI = {Positive: '😊', Negative: '😠', Neutral: '😐'};

async function api(url, opts = {}) {
  const res = await fetch(url, opts);
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (res.status === 401) { window.location = '/login'; throw new Error('Not logged in'); }
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}
function post(url, body) {
  return api(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
}
function badge(s) { return `<span class="badge-s badge-${s}">${s}</span>`; }
function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast-x'; t.textContent = msg; document.body.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}
function setBusy(btn, busy, label) {
  btn.disabled = busy;
  if (busy) { btn.dataset.l = btn.innerHTML; btn.innerHTML = `<span class="spin"></span>${label || 'Working...'}`; }
  else btn.innerHTML = btn.dataset.l || btn.innerHTML;
}
const charts = {};
function drawPie(id, p, n, u) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(document.getElementById(id), {
    type: 'doughnut',
    data: {labels: ['Positive', 'Negative', 'Neutral'], datasets: [{data: [p, n, u], backgroundColor: [COLORS.Positive, COLORS.Negative, COLORS.Neutral], borderWidth: 3, borderColor: '#fff'}]},
    options: {maintainAspectRatio: false, cutout: '62%', plugins: {legend: {position: 'bottom'}}, animation: {duration: 900}}
  });
}
function drawBar(id, p, n, u) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(document.getElementById(id), {
    type: 'bar',
    data: {labels: ['Positive', 'Negative', 'Neutral'], datasets: [{label: 'Comments', data: [p, n, u], backgroundColor: [COLORS.Positive, COLORS.Negative, COLORS.Neutral], borderRadius: 10}]},
    options: {maintainAspectRatio: false, plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true, ticks: {precision: 0}}}, animation: {duration: 900}}
  });
}
function toggleSidebar() { document.querySelector('.sidebar').classList.toggle('open'); }
