"""
Builds dataset/social_sentiment.csv automatically from the free NLTK
'twitter_samples' corpus (real tweets). Run:  python dataset/prepare_dataset.py

Labels:
  Positive / Negative -> 5000 tweets each, labelled in the corpus (emoticon-based)
  Neutral             -> (a) tweets from the corpus' unlabeled file and (b) plain
                         questions/statements from the NLTK chat corpus, kept only when
                         their VADER score is exactly 0 and no emoticon is present

NOTE: These are weak labels. For a stronger, human-labelled 3-class dataset,
download Kaggle 'Twitter Entity Sentiment Analysis' and place
'twitter_training.csv' in this folder; train_model.py will use it automatically.
"""
import json
import os
import re

import nltk
import pandas as pd
from nltk.corpus import nps_chat, twitter_samples
from nltk.sentiment.vader import SentimentIntensityAnalyzer

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "social_sentiment.csv")
nltk.download("twitter_samples", quiet=True)
nltk.download("vader_lexicon", quiet=True)
nltk.download("nps_chat", quiet=True)

EMOTICON = re.compile(r"[:;=8][\-o\*']?[\)\]\(\[dDpP/\\|]|[\)\]\(\[dDpP/\\|][\-o\*']?[:;=8]|<3")


def clean_raw(t):
    t = re.sub(r"http\S+", "", t)
    return re.sub(r"\s+", " ", t).strip()


pos = [clean_raw(t) for t in twitter_samples.strings("positive_tweets.json")]
neg = [clean_raw(t) for t in twitter_samples.strings("negative_tweets.json")]

sia = SentimentIntensityAnalyzer()
neutral = []
with open(twitter_samples.abspath("tweets.20150430-223406.json"), encoding="utf-8") as f:
    for line in f:
        try:
            tw = json.loads(line)
        except Exception:
            continue
        if tw.get("lang") != "en" or tw.get("text", "").startswith("RT"):
            continue
        text = clean_raw(tw["text"])
        if len(text.split()) < 5 or EMOTICON.search(text):
            continue
        if sia.polarity_scores(text)["compound"] == 0.0:
            neutral.append(text)

# Extra neutral examples: plain questions/statements from the NLTK NPS chat corpus
for post in nps_chat.xml_posts():
    t = re.sub(r"\s+", " ", post.text).strip()
    if (post.get("class") in ("Statement", "ynQuestion", "whQuestion", "Clarify")
            and len(t.split()) >= 4 and "User" not in t and not t.startswith(".")
            and not EMOTICON.search(t) and sia.polarity_scores(t)["compound"] == 0.0):
        neutral.append(t)

rows = ([(t, "Positive") for t in pos] + [(t, "Negative") for t in neg]
        + [(t, "Neutral") for t in neutral])
df = pd.DataFrame(rows, columns=["text", "sentiment"]).drop_duplicates("text")
df.to_csv(OUT, index=False)
print(df["sentiment"].value_counts())
print("Saved", OUT)
